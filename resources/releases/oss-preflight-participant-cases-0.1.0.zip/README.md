# Supplied-file pilot tasks

Participation is voluntary. Stop whenever you wish. The files are fictional;
no server, package, account, credentials, or live connection is needed.
Read TASK_CARDS.md and use the neutral participant-cases files. Follow the
facilitator's assigned order and current documentation baseline. Return your
proposed next action, uncertainty, and task time through the agreed private
study channel; do not include identifying information or credentials.

This packet omits facilitator answer keys. The complete project is open source;
report if you consulted its answers so the observation can be interpreted.
No human outcome, product superiority, or real-issue reproduction is implied.
